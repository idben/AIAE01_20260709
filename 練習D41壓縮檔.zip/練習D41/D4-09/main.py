# ✅ 全班成績檢查！先用迴圈做出「每個是否符合」的布林清單，再用 all()／any() 總結
# all()：全部為 True 才 True；any()：只要有一個 True 就 True
scores = [80, 95, 60, 100]

# TODO：
#   1. 用迴圈把「每個分數是否 >= 60」放進 pass_flags，再用 all() 判斷是否全及格 → all_pass
#   2. 用迴圈把「每個分數是否 == 100」放進 full_flags，再用 any() 判斷是否有人滿分 → has_full
pass_flags = []
full_flags = []
all_pass = None
has_full = None
