# D4-04 練習：權限管理（remove／discard）

## 題目

權限集合 `perms = {"read", "write", "delete"}`。
用 `remove()` 移除確定存在的 `"delete"`；用 `discard()` 移除不存在的 `"admin"`（不會報錯）。完成後應是 `{"read", "write"}`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `remove()` 遇到不存在的元素會報錯；`discard()` 不會
- 不確定元素在不在時，用 `discard()` 比較安全

## 這題常見錯誤

- 用 `remove("admin")` 移除不存在的元素（會 `KeyError`，這正是 `discard` 的用途）

## 這題在測什麼

- 是否分得清 `remove()` 與 `discard()` 的差別
