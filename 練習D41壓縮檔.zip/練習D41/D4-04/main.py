# 🔑 權限管理！remove 用在「確定存在」的元素，discard 用在「不確定存不存在」（不報錯）
perms = {"read", "write", "delete"}

# TODO：
#   1. 用 remove() 移除確定存在的 "delete"
#   2. 用 discard() 移除 "admin"（它不存在，discard 不會報錯）
#   完成後 perms 應是 {"read", "write"}
