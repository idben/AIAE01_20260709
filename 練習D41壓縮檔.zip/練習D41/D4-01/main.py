# 🙋 活動報名有人重複報名！用 set 去重，算出「不重複」的報名人數
# set 會自動去掉重複的元素（把 list 丟進 set() 就會去重）
signups = ["小明", "小華", "小明", "小美", "小華", "小明"]

# TODO：用 set() 去重、再用 len() 算出不重複的人數，存進 unique_count
unique_count = None
