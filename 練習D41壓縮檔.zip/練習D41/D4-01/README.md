# D4-01 練習：報名去重（set 去重）

## 題目

報名清單 `signups` 有重複。把它丟進 `set()` 去重、再用 `len()` 算出不重複人數，存進 `unique_count`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `set(signups)` 會自動去掉重複
- 再用 `len()` 算出剩幾個

## 這題常見錯誤

- 直接對原本的 list 算 `len()`（那會把重複的也算進去）

## 這題在測什麼

- 是否會用 `set()` 去重並搭配 `len()`
