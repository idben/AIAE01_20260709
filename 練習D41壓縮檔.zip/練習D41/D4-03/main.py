# 🏷️ 標籤系統！用 add 加一個標籤、用 update 一次加多個（重複的會自動忽略）
tags = {"news", "tech"}

# TODO：
#   1. 用 add() 把 "ai" 加進 tags
#   2. 用 update() 一次把 {"python", "ai"} 加進 tags（"ai" 重複會自動忽略）
#   完成後 tags 應包含 news、tech、ai、python 四個標籤
