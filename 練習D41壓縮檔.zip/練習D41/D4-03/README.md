# D4-03 練習：標籤系統（add／update）

## 題目

標籤集合 `tags = {"news", "tech"}`。
用 `add()` 加入 `"ai"`；用 `update()` 一次加入 `{"python", "ai"}`（重複的 `"ai"` 會自動忽略）。完成後應有 news、tech、ai、python 四個。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `add()` 一次加「一個」元素；`update()` 一次加「多個」
- set 會自動去重，重複的不會變兩份

## 這題常見錯誤

- 用 `add({"python", "ai"})` 想加多個（`add` 只能加一個，加多個要用 `update`）

## 這題在測什麼

- 是否分得清 `add()`（單個）與 `update()`（多個）
