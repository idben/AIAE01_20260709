# 👋 定義一個打招呼函式，greeting 有「預設值」"你好"
# 呼叫時若沒給 greeting，就用預設的 "你好"
def greet(name, greeting="你好"):
    # TODO：回傳「招呼語，名字」的字串（招呼語和名字中間用全形逗號「，」）
    pass
