# 🔢 使用者輸入的數字都是「字串」，用 map() 一次把整個清單轉成 int
raw = ["10", "20", "30"]

# TODO：用 map() 把 raw 每個元素轉成 int，再用 list() 收集起來，存進 nums
#       結果應是 [10, 20, 30]
nums = None
