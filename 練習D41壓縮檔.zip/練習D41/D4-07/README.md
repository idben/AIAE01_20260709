# D4-07 練習：排行榜排序（sorted）

## 題目

分數 `scores = [88, 95, 70, 100, 60]`。
用 `sorted()` 得到由小到大的 `ranked`；加 `reverse=True` 得到由大到小的 `ranked_desc`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `sorted(scores)` 回傳「新的」排序清單，預設由小到大
- 由大到小加參數：`sorted(scores, reverse=True)`

## 這題常見錯誤

- 把 `reverse=True` 寫成 `reverse=1` 或位置放錯
- 以為 `sorted()` 會改變原本的清單（它是回傳新的）

## 這題在測什麼

- 是否會用 `sorted()` 做升冪與降冪排序
