# 🏆 排行榜！用 sorted() 把分數排序（預設由小到大；加 reverse=True 由大到小）
scores = [88, 95, 70, 100, 60]

# TODO：
#       ranked：用 sorted() 把 scores 由小到大排序
#       ranked_desc：用 sorted() 加 reverse=True 由大到小排序
ranked = None
ranked_desc = None
