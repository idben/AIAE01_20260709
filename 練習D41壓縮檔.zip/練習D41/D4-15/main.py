# 📊 定義一個算平均的函式（帶入迴圈與 len；不用 sum）
# 用迴圈把清單裡的數字加總，再除以數量
def average(numbers):
    # TODO：用迴圈加總 numbers，再除以 len(numbers)，回傳平均
    pass
