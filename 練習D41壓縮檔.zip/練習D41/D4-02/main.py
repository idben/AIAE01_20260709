# 🚫 黑名單快速比對！用 in／not in 檢查帳號是否在黑名單裡（set 查詢很快）
blacklist = {"spam1", "bot2", "spam3"}

# TODO：
#       is_blocked：用 in 判斷 "bot2" 是否在黑名單裡 → 布林
#       is_clean：用 not in 判斷 "user9" 是否「不在」黑名單裡 → 布林
is_blocked = None
is_clean = None
