# D4-02 練習：黑名單比對（in／not in）

## 題目

黑名單 `blacklist = {"spam1", "bot2", "spam3"}`。
用 `in` 判斷 `"bot2"` 是否被封鎖（`is_blocked`）；用 `not in` 判斷 `"user9"` 是否乾淨（`is_clean`）。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `in`／`not in` 用在 set 上跟用在 list 上一樣
- 結果本身就是布林值

## 這題常見錯誤

- 想存數字 `1`／`0`（要存布林值）

## 這題在測什麼

- 是否會用 `in`／`not in` 檢查 set 成員
