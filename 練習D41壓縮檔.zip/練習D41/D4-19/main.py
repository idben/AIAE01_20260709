# 🎯 定義一個函式：從分數清單挑出「及格（>= 60）」的，並由高到低排序後回傳
# 帶入：迴圈篩選 ＋ append ＋ sorted
def passed_sorted(scores):
    # TODO：把及格（>= 60）的分數收集起來，再用 sorted 由大到小排序後回傳
    pass
