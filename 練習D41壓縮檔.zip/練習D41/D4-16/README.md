# D4-16 練習：全域計分（global）

## 題目

全域變數 `total = 0`，函式 `add_score(points)` 要能累加到 `total` 上。
函式外已呼叫 `add_score(10)`、`add_score(5)`，完成後 `total` 應是 `15`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 函式裡要「修改」全域變數前，必須先寫 `global total`
- 沒寫 `global` 的話，`total += points` 會被當成新的區域變數而報錯

## 這題常見錯誤

- 忘了 `global total`（會出現「區域變數在指派前被使用」的錯誤）

## 這題在測什麼

- 是否會用 `global` 在函式內修改全域變數
