# 🎮 遊戲全域計分！total 是全域變數，add_score 要能「累加」到它上面
# 提示：函式裡若要「修改」全域變數，必須先寫 global total
total = 0

def add_score(points):
    # TODO：用 global 讓函式能累加「全域的」total（total 加上 points）
    pass

# 下面兩次呼叫已經幫你寫好了（不用改）
add_score(10)
add_score(5)
