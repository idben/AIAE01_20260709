# 🔍 檢查資料型別！type() 回傳型別，isinstance() 判斷是不是某型別（回傳布林）
value = 42

# TODO：
#       t：用 type() 取得 value 的型別
#       is_int：用 isinstance() 判斷 value 是不是 int → 布林
#       is_str：用 isinstance() 判斷 value 是不是 str → 布林
t = None
is_int = None
is_str = None
