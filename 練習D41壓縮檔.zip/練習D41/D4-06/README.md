# D4-06 練習：型別檢查（type／isinstance）

## 題目

`value = 42`。用 `type()` 取得它的型別（`t`）；用 `isinstance()` 判斷它是不是 `int`（`is_int`）、是不是 `str`（`is_str`）。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `type(value)` 回傳型別本身（這裡是 `int`）
- `isinstance(value, int)` 回傳布林值

## 這題常見錯誤

- 把 `type()` 的結果和 `isinstance()` 的布林結果搞混
- `isinstance` 第二個參數要放型別（如 `int`），不是字串 `"int"`

## 這題在測什麼

- 是否會用 `type()` 與 `isinstance()`
