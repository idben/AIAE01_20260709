# ➗ 定義一個函式，同時回傳「商」和「餘數」（一次回傳兩個值）
# 提示：return 商, 餘數 會回傳一個 tuple；商用 //、餘數用 %
def div_and_mod(a, b):
    # TODO：回傳 (a 除以 b 的商, a 除以 b 的餘數)
    pass
