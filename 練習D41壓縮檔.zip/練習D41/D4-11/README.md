# D4-11 練習：長方形面積（def＋return）

## 題目

定義函式 `rectangle_area(width, height)`，回傳長方形面積（寬 × 高）。
test 會用不同的寬高呼叫你的函式來驗證（例如 `rectangle_area(3, 4)` 應回傳 `12`）。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 用 `return` 把結果「回傳」，不要用 `print`
- `return` 的值才會被 test 拿去比對

## 這題常見錯誤

- 用 `print` 代替 `return`（畫面看得到，但回傳的是 `None`，測不過）
- 忘了把 `pass` 換成 `return ...`

## 這題在測什麼

- 是否會用 `def` 定義函式並用 `return` 回傳結果
