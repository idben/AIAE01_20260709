# ▭ 定義一個函式，算出長方形的面積（寬 × 高）
# 提示：用 def 定義函式，用 return 把結果「回傳」出去（不是用 print）
def rectangle_area(width, height):
    # TODO：回傳長方形面積（寬 × 高）
    pass
