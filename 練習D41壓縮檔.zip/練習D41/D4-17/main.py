# 🔤 定義一個函式，算出清單裡有幾個「不重複」的元素（帶入 set）
def count_unique(items):
    # TODO：用 set() 去重、再用 len() 算不重複的數量，回傳它
    pass
