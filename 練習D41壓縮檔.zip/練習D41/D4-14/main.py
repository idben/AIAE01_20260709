# 📝 定義一個判斷及格的函式：分數 >= 60 回傳 "及格"，否則回傳 "不及格"
# 提示：函式裡也能用 if-else，再用 return 回傳結果
def check_pass(score):
    # TODO：score >= 60 回傳 "及格"，否則回傳 "不及格"
    pass
