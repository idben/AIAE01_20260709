# 🎓 兩個班級的選課名單，用集合運算找出各種關係
# 聯集 |（所有人）、交集 &（兩班都有）、差集 -（只在某一班）
class_a = {"小明", "小華", "小美"}
class_b = {"小華", "阿強", "小美"}

# TODO：
#       both：兩班「都有」的學生（用交集 &）
#       all_students：兩班「所有」學生（用聯集 |）
#       only_a：「只在」A 班的學生（用差集 -）
both = None
all_students = None
only_a = None
