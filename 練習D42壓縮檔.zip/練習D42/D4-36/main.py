# 📏 密碼長度分級！依長度回傳等級字串
# 規則：長度 < 6 → "太短"；6 到 9 → "普通"；>= 10 → "很長"
# 提示：先用 len(pwd) 取長度，再用 if / elif / else 分三段
def length_level(pwd):
    # TODO：依長度回傳 "太短" / "普通" / "很長"
    pass
