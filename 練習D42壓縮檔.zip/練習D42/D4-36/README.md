# D4-36 練習：密碼長度分級（if-elif-else）

## 題目

定義 `length_level(pwd)`，依密碼長度回傳等級：長度小於 6 回 `"太短"`；6 到 9 回 `"普通"`；10（含）以上回 `"很長"`。例如 `length_level("abc")` 回 `"太短"`、`length_level("abcdef")` 回 `"普通"`、`length_level("abcdefghij")` 回 `"很長"`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 先 `len(pwd)` 取長度
- `if / elif / else` 分三段，注意邊界（6 是「普通」、10 是「很長」）

## 這題常見錯誤

- 邊界弄反（例如把長度 6 判成「太短」）
- 只寫兩段漏了中間的「普通」

## 這題在測什麼

- 是否會用 `if-elif-else` 依範圍分級
