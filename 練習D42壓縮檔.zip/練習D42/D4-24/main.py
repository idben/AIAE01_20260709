# 🐞 這個計數器一直算不對！最常見的原因是「函式裡改全域卻忘了寫 global」
# 提示：要在函式內修改全域的 count，第一行要先宣告 global count
count = 0

def record():
    # TODO：用 global 正確地把「全域的」count 加 1
    pass

# 下面 3 次呼叫已經幫你寫好了（不用改）
record()
record()
record()
