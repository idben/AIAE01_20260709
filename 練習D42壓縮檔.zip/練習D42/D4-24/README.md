# D4-24 練習：抓漏 global（改錯題）

## 題目

`record()` 本來想把全域的 `count` 累加，但常見的 bug 是「忘了寫 `global`」。請正確完成 `record()`，讓它每次呼叫都把全域 `count` 加 1。呼叫 3 次後 `count` 應為 `3`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 函式內若要「修改」全域變數，第一行要先宣告 `global count`
- 忘了寫 `global`，Python 會把 `count` 當成新的區域變數

## 這題常見錯誤

- 只寫 `count += 1` 卻沒有 `global count`
- 以為在函式內改了就會影響全域（其實沒有）

## 這題在測什麼

- 是否能辨認並修正「忘記 global」造成的計數錯誤
