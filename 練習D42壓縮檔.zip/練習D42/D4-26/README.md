# D4-26 練習：訂單統計（一次改兩個全域）

## 題目

`order_count`（訂單數）與 `revenue`（總營收）都是全域變數，起始為 0。完成 `add_order(amount)`：每次呼叫把 `order_count` 加 1、`revenue` 加上 `amount`。呼叫 `add_order(120)`、`add_order(80)` 後，`order_count` 應為 `2`、`revenue` 應為 `200`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 一行 `global` 可同時宣告多個：`global order_count, revenue`
- 兩個變數各自累加

## 這題常見錯誤

- 只宣告其中一個全域變數
- 忘記 `revenue` 要「累加」而不是「覆蓋」

## 這題在測什麼

- 是否會用一次 `global` 宣告並更新多個全域變數
