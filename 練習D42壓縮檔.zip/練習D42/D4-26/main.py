# 📊 訂單統計！同一個函式要一次更新兩個全域變數：訂單數與總營收
# 提示：一行 global 可以同時宣告多個變數 → global order_count, revenue
order_count = 0
revenue = 0

def add_order(amount):
    # TODO：用 global 讓 order_count 加 1、revenue 加上 amount
    pass

# 下面的呼叫已經幫你寫好了（不用改）
add_order(120)
add_order(80)
