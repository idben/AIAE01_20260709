# D4-33 練習：密碼長度驗證（raise）

## 題目

定義 `validate_length(pwd)`：密碼長度不足 8 碼時用 `raise` 拋出 `ValueError`；長度足夠就回傳 `True`。例如 `validate_length("abcd1234")` 回 `True`、`validate_length("abc")` 應該要 `raise ValueError`。

> 這題用「例外版」測試：長度不足的輸入預期「應該拋出例外」才算通過。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 用 `len(pwd)` 取得長度
- 不足 8 就 `raise ValueError("...")`，足夠就 `return True`

## 這題常見錯誤

- 回傳 `False` 而不是 `raise`（本題要求用例外表達「不合法」）
- 邊界搞錯：長度剛好 8 應該算通過

## 這題在測什麼

- 是否會依條件用 `raise` 拋出例外（結合字串長度判斷）
