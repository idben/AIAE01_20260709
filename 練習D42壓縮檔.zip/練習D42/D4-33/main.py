# 🔑 密碼長度驗證！長度不足 8 碼就用 raise 拋出 ValueError（帶入字串 len）
# 提示：用 len() 取長度，不足 8 就用 raise 丟出一個 ValueError；足夠就回傳 True
def validate_length(pwd):
    # TODO：長度小於 8 就 raise ValueError；否則回傳 True
    pass
