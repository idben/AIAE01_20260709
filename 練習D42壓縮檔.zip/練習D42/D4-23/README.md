# D4-23 練習：含稅價格（讀全域不需 global）

## 題目

`TAX` 是全域稅率 `0.05`。定義 `price_with_tax(price)`，回傳含稅價格：原價 ＋ 原價 × `TAX`。例如 `price_with_tax(100)` 應回傳 `105.0`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 在函式裡「只是讀取」全域變數時，不需要寫 `global`，直接用 `TAX` 即可
- 記得用 `return` 回傳

## 這題常見錯誤

- 誤以為讀全域也要寫 `global`（讀不用、只有「修改」才要）
- 用 `print` 代替 `return`

## 這題在測什麼

- 是否理解「函式內讀全域」不需要 `global`
