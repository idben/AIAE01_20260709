# 📖 含稅價格！TAX 是全域稅率，函式只是「讀」它、不修改，所以不需要 global
# 提示：在函式裡「讀取」全域變數不用寫 global，直接用即可
TAX = 0.05

def price_with_tax(price):
    # TODO：回傳含稅價格＝ 原價 ＋ 原價 × TAX（直接讀全域 TAX）
    pass
