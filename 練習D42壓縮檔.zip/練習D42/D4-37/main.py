# 🔠 密碼含幾種字元類別？用 set 蒐集出現過的類別，最後回傳類別數
# 規則：小寫字母算一類、大寫字母算一類、數字算一類；回傳「出現的類別數」（0~3）
# 提示：逐字判斷 ch.islower() / ch.isupper() / ch.isdigit()，把類別名稱 add 進 set，最後回傳 len(set)
def kind_count(pwd):
    # TODO：用 set 蒐集出現的類別，回傳類別數
    pass
