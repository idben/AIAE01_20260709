# D4-31 練習：try 四區塊軌跡（else＋finally）

## 題目

定義 `run_task(will_fail)`，用一個 list `trace` 記錄執行路徑，最後回傳它：

- `try` 裡：`will_fail` 為 `True` 就 `raise ValueError`；沒 raise 就加入 `"try 沒出錯"`
- `except ValueError`：加入 `"except 接住"`
- `else`（try 完全沒出錯才執行）：加入 `"else 執行"`
- `finally`（無論如何都執行）：加入 `"finally 收尾"`

所以 `run_task(False)` 應回 `["try 沒出錯", "else 執行", "finally 收尾"]`；`run_task(True)` 應回 `["except 接住", "finally 收尾"]`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `else` 只有在 `try` 沒發生例外時才會跑
- `finally` 不管有沒有出錯都會跑（適合收尾／釋放資源）
- 先建立空 list，過程中 `append`，最後 `return`

## 這題常見錯誤

- 把 `else` 的內容誤放進 `try` 裡
- 忘了 `finally` 在「有出錯」時也要執行

## 這題在測什麼

- 是否理解 `try / except / else / finally` 四個區塊的執行時機
