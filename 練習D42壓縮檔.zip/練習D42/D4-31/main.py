# 🧹 try 的四個區塊！這題用一個 list 記錄「執行到哪裡」，看清楚 else 與 finally
# 規則：
#   try 裡：will_fail 為 True 就 raise ValueError；沒 raise 的話往 trace 加 "try 沒出錯"
#   except ValueError 裡：往 trace 加 "except 接住"
#   else 裡（try 完全沒出錯才會執行）：往 trace 加 "else 執行"
#   finally 裡（無論如何都會執行）：往 trace 加 "finally 收尾"
# 最後回傳 trace
def run_task(will_fail):
    # TODO：依上面規則用 try / except / else / finally 完成，並回傳 trace
    pass
