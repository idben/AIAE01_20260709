# D4-28 練習：安全轉整數（try-except ValueError）

## 題目

定義 `to_int(text)`：能把字串轉成整數就回傳該整數；遇到像 `"abc"` 這種轉不了的，改回傳 `0`。例如 `to_int("123")` 回 `123`、`to_int("abc")` 回 `0`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `int("abc")` 會拋 `ValueError`
- `try:` 裡做轉換，`except ValueError:` 裡回傳 `0`

## 這題常見錯誤

- 沒接住例外，遇到非數字字串就崩潰
- 用了太大的 `except`（本題只需捕捉 `ValueError`）

## 這題在測什麼

- 是否會用 `try-except` 捕捉 `ValueError`
