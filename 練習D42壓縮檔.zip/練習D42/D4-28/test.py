import subprocess
import sys
from pathlib import Path

import main as answer

# (函式名稱, 引數 tuple, 預期回傳值)
run_cases = [
    ('to_int', ('123',), 123),
    ('to_int', ('abc',), 0),
]

submit_cases = run_cases


def test(name, args, expected) -> bool:
    print("---------------------------------")
    call_str = f"{name}({', '.join(repr(a) for a in args)})"
    print(f"呼叫：    {call_str}")
    print(f"預期：    {expected!r}")
    if not hasattr(answer, name):
        print(f"錯誤：    main.py 裡找不到函式 {name}，請確認名稱有沒有拼對")
        return False
    func = getattr(answer, name)
    if not callable(func):
        print(f"錯誤：    {name} 不是一個函式（要用 def 定義）")
        return False
    try:
        result = func(*args)
    except Exception as e:
        print(f"錯誤：    呼叫 {name} 時發生例外：{e}")
        return False
    print(f"實際：    {result!r}")
    if isinstance(expected, bool) and not isinstance(result, bool):
        print("提示：    要回傳布林值 True 或 False")
        return False
    return result == expected


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        correct = test(*test_case)
        if correct:
            passed += 1
            print("通過")
        else:
            failed += 1
            print("失敗")
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
