# 🔢 安全轉整數！int("abc") 會拋 ValueError，用 try-except 擋下來
# 提示：try 裡做 int(text)；except ValueError 時回傳 0
def to_int(text):
    # TODO：轉得成整數就回整數；轉不成（ValueError）回傳 0
    pass
