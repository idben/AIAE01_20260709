# 🔡 密碼是否含數字？用迴圈逐字檢查，只要有任一個是數字就回 True
# 提示：for 逐字走訪，用字元的 .isdigit() 判斷；找到就 return True，全走完沒找到 return False
def has_digit(pwd):
    # TODO：用迴圈檢查 pwd 是否含數字，回傳布林
    pass
