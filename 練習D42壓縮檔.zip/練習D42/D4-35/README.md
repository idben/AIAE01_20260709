# D4-35 練習：密碼是否含數字（迴圈＋isdigit）

## 題目

定義 `has_digit(pwd)`：用迴圈逐字檢查密碼，只要含有任一個數字字元就回傳 `True`，否則回傳 `False`。例如 `has_digit("abc123")` 回 `True`、`has_digit("abcdef")` 回 `False`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `for ch in pwd:` 逐字走訪
- 單一字元用 `ch.isdigit()` 判斷是不是數字
- 找到就可以直接 `return True`；迴圈跑完都沒找到再 `return False`

## 這題常見錯誤

- 對整個字串用 `pwd.isdigit()`（那是「整串都要是數字」才 True）
- 回傳字串 `"True"` 而不是布林 `True`

## 這題在測什麼

- 是否會用迴圈逐字檢查並回傳布林
