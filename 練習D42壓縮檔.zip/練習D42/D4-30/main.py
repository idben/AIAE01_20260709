# ➕ 型別防呆！數字加字串會拋 TypeError，用 try-except 接住
# 提示：try 裡做 a + b；except TypeError 時回傳 None
def safe_add(a, b):
    # TODO：兩者能相加就回結果；型別不符（TypeError）回傳 None
    pass
