# D4-30 練習：型別防呆（try-except TypeError）

## 題目

定義 `safe_add(a, b)`：兩者能相加就回結果；如果型別不相容（例如數字加字串）會拋 `TypeError`，這時回傳 `None`。例如 `safe_add(3, 4)` 回 `7`、`safe_add(3, "x")` 回 `None`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `3 + "x"` 會拋 `TypeError`
- `try:` 裡做相加，`except TypeError:` 裡回傳 `None`

## 這題常見錯誤

- 沒接住例外，型別不符就崩潰
- 把 `TypeError` 寫成 `ValueError`

## 這題在測什麼

- 是否會用 `try-except` 捕捉 `TypeError`
