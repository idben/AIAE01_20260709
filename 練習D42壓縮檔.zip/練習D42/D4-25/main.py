# ♻️ 最佳實務：能不用全域就不用！這題用「參數傳入、回傳送出」取代全域變數
# 提示：不要用 global，只靠參數 n 與 return 完成
def increase(n):
    # TODO：回傳 n ＋ 1
    pass
