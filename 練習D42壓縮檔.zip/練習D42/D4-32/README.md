# D4-32 練習：年齡驗證（raise ValueError）

## 題目

定義 `check_age(age)`：如果 `age` 小於 0，用 `raise` 主動拋出 `ValueError`；否則回傳 `age`。例如 `check_age(20)` 回 `20`、`check_age(-5)` 應該要 `raise ValueError`。

> 這題用「例外版」測試：某些輸入預期「應該拋出例外」才算通過，畫面會顯示「預期：拋出 ValueError」。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 用 `raise ValueError("...")` 主動拋出例外
- 正常情況記得 `return age`

## 這題常見錯誤

- 用 `print` 印錯誤訊息，卻沒有真的 `raise`
- 負數時沒有拋錯，直接回傳了

## 這題在測什麼

- 是否會用 `raise` 主動拋出 `ValueError`（並在正常輸入回傳）
