# 🚨 主動拋錯！年齡不該是負數，遇到負數就用 raise 主動拋出 ValueError
# 提示：先判斷 age 是否小於 0，是的話用 raise 丟出一個 ValueError；不是就正常回傳 age
def check_age(age):
    # TODO：age 小於 0 就 raise ValueError；否則回傳 age
    pass
