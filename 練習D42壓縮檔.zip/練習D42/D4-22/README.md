# D4-22 練習：帳戶存提款（global 加減）

## 題目

`balance` 是全域變數，起始 `1000`。完成 `deposit(n)`（存入，balance 加 n）與 `withdraw(n)`（領出，balance 減 n）。下方已呼叫 `deposit(500)` 與 `withdraw(200)`，跑完 `balance` 應為 `1300`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 兩個函式都要在第一行宣告 `global balance`
- 存款用 `+=`，領款用 `-=`

## 這題常見錯誤

- 只有一個函式寫了 `global`，另一個忘了
- 用回傳值卻沒改到全域的 `balance`

## 這題在測什麼

- 是否會在多個函式中用 `global` 修改同一個全域變數
