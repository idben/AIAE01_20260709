# 💰 帳戶存提款！balance 是全域變數，deposit 存錢、withdraw 領錢都要改到它
# 提示：兩個函式要「修改」全域 balance，都要先寫 global balance
balance = 1000

def deposit(n):
    # TODO：用 global 讓 balance 增加 n（存款）
    pass

def withdraw(n):
    # TODO：用 global 讓 balance 減少 n（領款）
    pass

# 下面的呼叫已經幫你寫好了（不用改）
deposit(500)
withdraw(200)
