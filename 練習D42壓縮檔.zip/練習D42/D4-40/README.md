# D4-40 練習：密碼健檢報告（capstone，回傳 dict）

## 題目

這是下午的綜合收尾題。定義 `health_report(pwd)`，回傳一個 dict：

```
{"length": 密碼長度, "has_digit": 是否含數字(布林), "strength": 強度等級}
```

強度規則同前面：長度 ≥ 8、含數字、含符號（`!@#`）各 +1；分數 0 到 1 為 `"弱"`、2 為 `"中"`、3 為 `"強"`。

例如：
- `health_report("abc")` 回 `{"length": 3, "has_digit": False, "strength": "弱"}`
- `health_report("abcd123!")` 回 `{"length": 8, "has_digit": True, "strength": "強"}`

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 長度用 `len()`、是否含數字用迴圈逐字判斷
- 強度沿用「計分再分級」的做法
- 最後用 `{ "鍵": 值 }` 把三項組成 dict 回傳

## 這題常見錯誤

- `has_digit` 回傳字串而不是布林
- dict 的鍵拼錯（要用 `length`、`has_digit`、`strength`）

## 這題在測什麼

- 是否能整合 `len`／迴圈／條件／函式，回傳結構化的 dict（綜合收尾）
