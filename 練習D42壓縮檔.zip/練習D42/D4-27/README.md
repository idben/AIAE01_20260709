# D4-27 練習：安全除法（try-except ZeroDivisionError）

## 題目

定義 `safe_divide(a, b)`：能整除就回傳商；當 `b` 為 0 時不要讓程式崩潰，改回傳字串 `"不能除以零"`。例如 `safe_divide(10, 2)` 回 `5.0`、`safe_divide(10, 0)` 回 `"不能除以零"`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `try:` 裡放會出錯的 `a / b`
- `except ZeroDivisionError:` 裡回傳提示字串

## 這題常見錯誤

- 沒有用 `try-except`，除以 0 直接讓程式崩潰
- 捕捉了例外卻忘記 `return` 提示字串

## 這題在測什麼

- 是否會用 `try-except` 捕捉 `ZeroDivisionError`
