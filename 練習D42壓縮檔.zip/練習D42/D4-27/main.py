# ➗ 安全除法！除法可能遇到「除以 0」而出錯，用 try-except 接住它
# 提示：try 裡做 a / b；except ZeroDivisionError 時回傳字串 "不能除以零"
def safe_divide(a, b):
    # TODO：能除就回商；除以 0 時回傳 "不能除以零"
    pass
