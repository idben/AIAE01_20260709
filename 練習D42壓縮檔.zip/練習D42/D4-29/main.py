# 📇 安全取索引！索引超出範圍會拋 IndexError，用 try-except 接住
# 提示：try 裡做 items[i]；except IndexError 時回傳 None
def get_item(items, i):
    # TODO：取得到就回該元素；索引超出範圍（IndexError）回傳 None
    pass
