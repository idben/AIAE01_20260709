# D4-29 練習：安全取索引（try-except IndexError）

## 題目

定義 `get_item(items, i)`：`items` 是一個 list，回傳第 `i` 個元素；如果 `i` 超出範圍，不要崩潰，改回傳 `None`。例如 `get_item(["a","b","c"], 1)` 回 `"b"`、`get_item(["a","b"], 5)` 回 `None`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 存取超出範圍的索引會拋 `IndexError`
- `try:` 裡取 `items[i]`，`except IndexError:` 裡回傳 `None`

## 這題常見錯誤

- 直接 `return items[i]` 沒有防護，越界就崩潰
- 回傳字串 `"None"` 而不是真正的 `None`

## 這題在測什麼

- 是否會用 `try-except` 捕捉 `IndexError`（並帶入 list 索引）
