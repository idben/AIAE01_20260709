# 🧮 多重 except！先把文字轉數字（可能 ValueError），再相除（可能 ZeroDivisionError）
# 規則：
#   先 int() 轉換 a_text 與 b_text，再回傳 a / b
#   轉換失敗（ValueError）回傳 "格式錯誤"
#   除以 0（ZeroDivisionError）回傳 "不能除以零"
# 提示：一個 try 可以接多個 except，分別處理不同錯誤
def safe_div_text(a_text, b_text):
    # TODO：用 try 搭配兩個 except 完成
    pass
