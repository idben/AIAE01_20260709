# D4-34 練習：多重 except（先轉型再相除）

## 題目

定義 `safe_div_text(a_text, b_text)`：先把兩個字串用 `int()` 轉成數字再相除，回傳商。過程中：

- 轉換失敗（`ValueError`）回傳 `"格式錯誤"`
- 除以 0（`ZeroDivisionError`）回傳 `"不能除以零"`

例如 `safe_div_text("10","2")` 回 `5.0`、`safe_div_text("x","2")` 回 `"格式錯誤"`、`safe_div_text("10","0")` 回 `"不能除以零"`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 一個 `try` 底下可以接多個 `except`，各自處理不同例外
- 由「具體的例外」分別捕捉，訊息才精準

## 這題常見錯誤

- 只寫一個 `except` 把兩種錯誤混在一起
- 轉型與相除放在不同 `try`，導致漏接

## 這題在測什麼

- 是否會用「一個 try 搭配多個 except」處理不同例外
