# 🎮 遊戲過關計數！level 是全域變數，每呼叫一次 next_level 就要「加一關」
# 提示：函式裡要「修改」全域變數，第一行必須先寫 global level
level = 0

def next_level():
    # TODO：用 global 讓函式能把「全域的」level 加 1
    pass

# 下面 5 次呼叫已經幫你寫好了（不用改）
next_level()
next_level()
next_level()
next_level()
next_level()
